% open the Simulink model
open_system('MIDC_calculation.slx')

% Set the stop time for the simulation
stopTime = 1180;

% Load the drive cycle data from an Excel file
drive_cycle = xlsread('MIDC_1180');

% Define other parameters
Mass = 1200;
g = 9.81;

% Rolling resistance
CRR = 0.01;

% Aerodynamic
Cd = 0.30;
Af = 2.5;
rho = 1.17692;

% Inertia
beta = 1.035;
mi = beta * Mass;

% Grade
deg = 0;

DRR = 0.27; % Dynamic Falling Radius
GR = 10;    % Gear ratio
TE = 0.93;  % Transmission efficiency
ME = 0.8;   % Motor efficiency

% Battery parameters
Cap = 20000;
DOD = 0.9;

% Simulate the model
sim('MIDC_calculation')
